# bnbtiger-tooling

Node.js script to interact with BNBTiger (contract `0xAC68931B666E086E9de380CFDb0Fb5704a35dc2D`)
It can:
- Read token info
- Transfer 25 tokens to synced wallet `0x7A9230B998C5C90538a92a66E074be35dfcE21e2`
- Send incremental ("step") pool increases

## Scripts
- `npm run read` → check token info
- `npm run transfer` → send 25 tokens
- `npm run step` → send incremental token amounts
