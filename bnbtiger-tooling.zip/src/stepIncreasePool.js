import dotenv from "dotenv";
import { ethers } from "ethers";

dotenv.config();

const provider = new ethers.JsonRpcProvider(process.env.RPC_URL);
const wallet = new ethers.Wallet(process.env.PRIVATE_KEY, provider);
const tokenAddress = process.env.TOKEN_ADDRESS;
const poolAddress = process.env.TO_ADDRESS;

const ABI = [
  "function decimals() view returns (uint8)",
  "function transfer(address to, uint amount) returns (bool)"
];

async function main() {
  const token = new ethers.Contract(tokenAddress, ABI, wallet);
  const decimals = Number(await token.decimals());

  const steps = [1, 2, 4, 8, 10];

  for (let i = 0; i < steps.length; i++) {
    const amount = ethers.parseUnits(steps[i].toString(), decimals);
    console.log(`Step ${i + 1}: Sending ${steps[i]} tokens...`);
    const tx = await token.transfer(poolAddress, amount);
    console.log("Tx hash:", tx.hash);
    await tx.wait();
  }

  console.log("✅ All steps completed successfully!");
}

main().catch(console.error);
