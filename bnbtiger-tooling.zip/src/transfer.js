import dotenv from "dotenv";
import { ethers } from "ethers";

dotenv.config();

const provider = new ethers.JsonRpcProvider(process.env.RPC_URL);
const wallet = new ethers.Wallet(process.env.PRIVATE_KEY, provider);
const tokenAddress = process.env.TOKEN_ADDRESS;
const to = process.env.TO_ADDRESS;

const ABI = [
  "function decimals() view returns (uint8)",
  "function transfer(address to, uint amount) returns (bool)"
];

async function main() {
  const token = new ethers.Contract(tokenAddress, ABI, wallet);
  const decimals = Number(await token.decimals());
  const amount = ethers.parseUnits("25", decimals);

  console.log(`Transferring 25 tokens to ${to}...`);
  const tx = await token.transfer(to, amount);
  console.log("Tx sent:", tx.hash);

  await tx.wait();
  console.log("✅ Transaction confirmed!");
}

main().catch(console.error);
